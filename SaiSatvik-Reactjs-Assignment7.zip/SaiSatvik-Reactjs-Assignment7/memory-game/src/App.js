import React, { useState, useEffect } from 'react';
import './App.css';

const generateCards = () => {
  let cardValues = [];
  for (let i = 1; i <= 8; i++) {
    cardValues.push(i, i); 
  }
  return cardValues.sort(() => Math.random() - 0.5); 
};

function App() {
  const [cards, setCards] = useState(generateCards());
  const [openedCards, setOpenedCards] = useState([]);
  const [matchedCards, setMatchedCards] = useState([]);
  const [moves, setMoves] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [startTime, setStartTime] = useState(null);
  const [bestScore, setBestScore] = useState(localStorage.getItem('bestScore') || null);


  const handleCardClick = (index) => {
    if (openedCards.length === 2 || openedCards.includes(index) || matchedCards.includes(index)) {
      return;
    }

    const newOpenedCards = [...openedCards, index];
    setOpenedCards(newOpenedCards);

    if (newOpenedCards.length === 2) {
      setMoves(moves + 1);
      checkForMatch(newOpenedCards);
    }

    if (!startTime) {
      setStartTime(Date.now()); 
    }
  };


  const checkForMatch = (opened) => {
    const [firstIndex, secondIndex] = opened;
    if (cards[firstIndex] === cards[secondIndex]) {
      setTimeout(() => {
        setMatchedCards([...matchedCards, firstIndex, secondIndex]);
        setOpenedCards([]);
      }, 1000); 
    } else {
      setTimeout(() => setOpenedCards([]), 1000);
    }
  };

  useEffect(() => {
    if (matchedCards.length === cards.length) {
      setGameOver(true);
      const timeTaken = Math.floor((Date.now() - startTime) / 1000);
      if (!bestScore || timeTaken < bestScore) {
        localStorage.setItem('bestScore', timeTaken);
        setBestScore(timeTaken);
      }
    }
  }, [matchedCards, cards.length, startTime, bestScore]);

  const renderCards = () => {
    return cards.map((card, index) => {
      if (matchedCards.includes(index)) return null; 
      return (
        <div
          key={index}
          className={`card ${openedCards.includes(index) ? 'flipped' : ''}`}
          onClick={() => handleCardClick(index)}
        >
          {openedCards.includes(index) ? card : '?'}
        </div>
      );
    });
  };

  const resetGame = () => {
    setCards(generateCards());
    setOpenedCards([]);
    setMatchedCards([]);
    setMoves(0);
    setGameOver(false);
    setStartTime(null);
  };

  return (
    <div className="memory-game">
      <h1>Memory Game</h1>
      <div className="board">
        {renderCards()}
      </div>
      <div className="info">
        <p>Moves: {moves}</p>
        {gameOver && <p>Game Over! Time Taken: {Math.floor((Date.now() - startTime) / 1000)} seconds</p>}
        {bestScore && <p>Best Time: {bestScore} seconds</p>}
        <button onClick={resetGame}>Restart Game</button>
      </div>
    </div>
  );
}

export default App;
