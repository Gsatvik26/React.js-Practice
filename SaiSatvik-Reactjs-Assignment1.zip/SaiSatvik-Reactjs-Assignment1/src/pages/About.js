import React from 'react';

const About = () => {
  return (
    <div className="home-container">
      <div className="image-container">
        <img src="/AIIT.jpeg" alt="Tech Enthusiasm" />
        <div className="text-overlay">
          <h1>About Us</h1>
          <p>We offer training on various IT services.</p>
        </div>
      </div>
    </div>
  );
};

export default About;
