import React, { useState } from 'react';
import '../LoginSignup.css'; // Import your CSS file

const LoginSignup = () => {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="login-signup-container">
      <h1>{isLogin ? 'Login' : 'Signup'}</h1>
      <form>
        <div>
          <label>Email:</label>
          <input type="email" required />
        </div>
        <div>
          <label>Password:</label>
          <input type="password" required />
        </div>
        {!isLogin && (
          <div>
            <label>Confirm Password:</label>
            <input type="password" required />
          </div>
        )}
        <button type="submit">{isLogin ? 'Login' : 'Signup'}</button>
      </form>
      <p>
        {isLogin ? 'Don’t have an account?' : 'Already have an account?'}
        <button onClick={() => setIsLogin(!isLogin)}>
          {isLogin ? ' Signup' : ' Login'}
        </button>
      </p>
    </div>
  );
};

export default LoginSignup;
