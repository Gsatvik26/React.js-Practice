import React from 'react';
import '../Home.css'; // Import your CSS file

const Home = () => {
  return (
    <div className="home-container">
      <div className="image-container">
        <img src="/AIIT.jpeg" alt="Tech Enthusiasm" />
        <div className="text-overlay">
          <h1>Welcome to AI-Based-IT-Training Website</h1>
          <p>Here you can get trained on IT services with the help of AI.</p>
        </div>
      </div>
    </div>
  );
};

export default Home;
