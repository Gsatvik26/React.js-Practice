import React from 'react';

const Contact = () => {
  return (
    <div className="home-container">
      <div className="image-container">
        <img src="/AIIT.jpeg" alt="Tech Enthusiasm" />
        <div className="text-overlay">
          <h1>Contact Us</h1>
          <p>Email: training@gmail.com</p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
