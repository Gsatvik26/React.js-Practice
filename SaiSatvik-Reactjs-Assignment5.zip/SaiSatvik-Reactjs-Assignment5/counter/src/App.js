import { useState } from "react";

function App() {
  const [count, setCount] = useState(2);
  return (
    <div className="App">
      <h1>counter: {count}</h1>
      <div className="button-container">
        <button className="btn" onClick={() => setCount(count => count - 1)}>
          decrease
        </button>
        <button className="btn" onClick={() => setCount(count => count + 1)}>
          Increment
        </button>
      </div>
    </div>
  );
}

export default App;
