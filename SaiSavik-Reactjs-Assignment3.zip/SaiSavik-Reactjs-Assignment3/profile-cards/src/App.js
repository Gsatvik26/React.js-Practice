import React from 'react';
import ProfileCard from './ProfileCard';

function App() {
  return (
    <div className="App">
      <h1>User Profile Cards</h1>
      <div className="profile-cards">
        <ProfileCard
          profileImg='satvik.jpg'
          title= 'Student, Btech'
          name='Satvik Gajula'
          age = '21'
          location= 'Hyderabad, India'
          bio= 'Satvik is currently pursuing Btech as a CSE major at Anurag University.'
          skills={['Student']}
          lastSeen={new Date('2024-09-19T08:00:00')}
        />
        <ProfileCard
          profileImg="satvik.jpg"
          name="Varun"
          title= 'Student, Btech'
          age={52}
          location="Hyderabad,India"
          bio= 'I am currently working as a flim director in tollywood film industry.'
          skills={['Actor', 'Film Director']}
          lastSeen={new Date('2024-09-18T08:00:00')}
        />
      </div>
    </div>
  );
}

export default App;
