import React from 'react';
import ProfileCard from './ProfileCard';
import profiles from './profiles.json';

function App() {
  return (
    <div className="App">
      <h1>User Profile Cards</h1>
      <div className="profile-cards">
        {profiles.map((profile, index) => (
          <ProfileCard
            key={index} 
            profileImg={profile.profileImg}
            name={profile.name}
            age={profile.age}
            location={profile.location}
            skills={profile.skills}
            lastSeen={new Date(profile.lastSeen)} 
          />
        ))}
      </div>
    </div>
  );
}

export default App;
