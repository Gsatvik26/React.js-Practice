import React from 'react';
import './ProfileCard.css';

function ProfileCard({ profileImg, name, title, age, location, bio, skills, lastSeen }) {
  const getLastSeen = (date) => {
    const now = new Date();
    const diffInMs = now - date;
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInDays > 7) {
      return 'Last seen several days ago';
    } else if (diffInDays > 1) {
      return `Last seen ${diffInDays} days ago`;
    } else {
      return `Last seen ${diffInHours} hours ago`;
    }
  };

  return (
    <div className="profile-card">
      <img src={profileImg} alt={`${name}'s profile`} className="profile-img" />
      <h2>{name}, {age}</h2>
      <h3>{title}</h3>
      <p>{location}</p>
      <p>{bio}</p>
      
      <div className="skills">
        <strong>Skills:</strong>
        <ul>
          {skills && skills.map((skill, index) => <li key={index}>{skill}</li>)}
        </ul>
      </div>


      <p className="last-seen">{getLastSeen(lastSeen)}</p>


      <div className="button-group">
        <button className="view-cv-btn">View CV</button>
        <button className="make-offer-btn">Make Offer</button>
      </div>
    </div>
  );
}

export default ProfileCard;
