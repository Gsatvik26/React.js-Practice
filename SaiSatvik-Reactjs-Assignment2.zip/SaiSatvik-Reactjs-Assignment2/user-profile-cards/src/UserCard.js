// src/UserCard.js
import React from "react";
import "./UserCard.css"; // Import CSS for styling

const UserCard = ({ user }) => {
  return (
    <div className="user-card">
      <div className="user-header">
        <img src={user.avatar} alt={user.name} className="user-avatar" />
        <div className="user-details">
          <h3>{user.title}</h3>
          <p>{user.rate}</p>
        </div>
      </div>
      <div className="user-info">
        <h2>
          {user.name}, {user.age}
        </h2>
        <p>
          <i className="fa fa-map-marker-alt"></i> {user.location}
        </p>
        <p>{user.bio}</p>
      </div>
      <div className="user-actions">
        <button className="btn btn-cv">View CV</button>
        <button className="btn btn-offer">Make Offer</button>
      </div>
      <div className="user-status">
        {user.isOnline ? (
          <span className="status online">Online</span>
        ) : (
          <span className="status offline">Last seen: {user.lastSeen}</span>
        )}
      </div>
    </div>
  );
};

export default UserCard;
