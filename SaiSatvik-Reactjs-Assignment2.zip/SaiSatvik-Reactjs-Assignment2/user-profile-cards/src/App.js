import React from 'react';
import ProfileCards from './ProfileCards';

const App = () => {
    return (
        <div>
            <h1 style={{ textAlign: 'center' }}>User Profile Cards</h1>
            <ProfileCards />
        </div>
    );
};

export default App;