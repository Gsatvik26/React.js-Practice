import React from 'react';
import UserCard from './UserCard';

const ProfileCards = () => {
    const users = [
        {
            avatar: 'satvik.jpg',
            title: 'Student, Btech',
            name: 'Satvik Gajula',
            age: 21,
            location: 'Hyderabad, India',
            bio: 'Satvik is currently pursuing Btech as a CSE major at Anurag University.',
            isOnline: true,
        },
        {
            avatar: '',
            title: 'Student, Btech',
            name: 'Tarun Reddy',
            age: 21,
            location: 'Amaravathi, India',
            bio: 'Tarun is currently pursuing Btech as an AIML major at VIT-AP.',
            isOnline: false,
            lastSeen: '17 minutes ago',
        }
    ];

    return (
        <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap' }}>
            {users.map((user, index) => (
                <UserCard key={index} user={user} />
            ))}
        </div>
    );
};

export default ProfileCards;
